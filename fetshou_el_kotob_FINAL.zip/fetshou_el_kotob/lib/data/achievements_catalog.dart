import '../models/bible_models.dart';

/// Static list of achievements. Unlocking is evaluated live against
/// AchievementStats — nothing is stored except which ones the user has
/// already seen unlocked (handled in AppState), so the list stays the
/// single source of truth.
final List<Achievement> achievementsCatalog = [
  Achievement(
    id: 'first_chapter',
    title: 'أول إصحاح',
    description: 'قرأت أول إصحاح لك في رحلتك',
    icon: 'auto_stories',
    isUnlocked: (s) => s.chaptersCompleted >= 1,
  ),
  Achievement(
    id: 'first_book',
    title: 'أول سفر',
    description: 'أنهيت أول سفر كامل',
    icon: 'menu_book',
    isUnlocked: (s) => s.booksCompleted >= 1,
  ),
  Achievement(
    id: 'streak_7',
    title: '7 أيام متتالية',
    description: 'حافظت على قراءتك لمدة أسبوع كامل',
    icon: 'local_fire_department',
    isUnlocked: (s) => s.currentStreak >= 7 || s.longestStreak >= 7,
  ),
  Achievement(
    id: 'streak_30',
    title: '30 يومًا',
    description: 'شهر كامل من المثابرة في القراءة',
    icon: 'whatshot',
    isUnlocked: (s) => s.currentStreak >= 30 || s.longestStreak >= 30,
  ),
  Achievement(
    id: 'chapters_100',
    title: '100 إصحاح',
    description: 'قطعت 100 إصحاح في رحلتك',
    icon: 'stacked_bar_chart',
    isUnlocked: (s) => s.chaptersCompleted >= 100,
  ),
  Achievement(
    id: 'chapters_500',
    title: '500 إصحاح',
    description: 'قطعت 500 إصحاح في رحلتك',
    icon: 'leaderboard',
    isUnlocked: (s) => s.chaptersCompleted >= 500,
  ),
  Achievement(
    id: 'halfway',
    title: 'نصف الطريق',
    description: 'وصلت لمنتصف الكتاب المقدس',
    icon: 'flag',
    isUnlocked: (s) => s.percentComplete >= 50,
  ),
  Achievement(
    id: 'whole_bible',
    title: 'الكتاب كله',
    description: 'أتممت قراءة الكتاب المقدس كاملًا 🎉',
    icon: 'emoji_events',
    isUnlocked: (s) => s.percentComplete >= 100,
  ),
];
