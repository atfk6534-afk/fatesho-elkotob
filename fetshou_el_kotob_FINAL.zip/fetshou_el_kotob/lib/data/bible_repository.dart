import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models/bible_models.dart';

/// Loads the canonical Bible structure from assets/data/bible_canon.json.
/// This is the single source of truth — nothing else in the app should
/// hard-code book names, chapter counts, or ordering.
class BibleRepository {
  BibleRepository._();
  static final BibleRepository instance = BibleRepository._();

  List<BibleBook>? _books;
  BibleMeta? _meta;

  Future<void> load() async {
    if (_books != null) return;
    final raw = await rootBundle.loadString('assets/data/bible_canon.json');
    final json = jsonDecode(raw) as Map<String, dynamic>;
    _meta = BibleMeta.fromJson(json['meta'] as Map<String, dynamic>);
    final list = (json['books'] as List)
        .map((b) => BibleBook.fromJson(b as Map<String, dynamic>))
        .toList()
      ..sort((a, b) => a.canonicalOrder.compareTo(b.canonicalOrder));
    _books = list;
  }

  List<BibleBook> get books {
    assert(_books != null, 'BibleRepository.load() must be called before use');
    return _books!;
  }

  BibleMeta get meta {
    assert(_meta != null, 'BibleRepository.load() must be called before use');
    return _meta!;
  }

  List<BibleBook> get oldTestamentBooks => books.where((b) => b.testament == Testament.ot).toList();
  List<BibleBook> get newTestamentBooks => books.where((b) => b.testament == Testament.nt).toList();

  BibleBook bookById(String id) => books.firstWhere((b) => b.id == id);

  int get totalChapters => books.fold(0, (sum, b) => sum + b.chapterCount);
}
