import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../models/bible_models.dart';
import '../../theme/app_theme.dart';
import 'book_detail_screen.dart';

class BooksScreen extends StatefulWidget {
  final bool embedded;
  const BooksScreen({super.key, this.embedded = false});

  @override
  State<BooksScreen> createState() => _BooksScreenState();
}

class _BooksScreenState extends State<BooksScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    final content = DefaultTabController(
      length: 3,
      child: Column(
        children: [
          if (!widget.embedded)
            AppBar(title: const Text('الأسفار')),
          TabBar(
            controller: _tabController,
            tabs: const [Tab(text: 'الكل'), Tab(text: 'العهد القديم'), Tab(text: 'العهد الجديد')],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _BookList(books: app.bible.books),
                _BookList(books: app.bible.oldTestamentBooks),
                _BookList(books: app.bible.newTestamentBooks),
              ],
            ),
          ),
        ],
      ),
    );

    if (widget.embedded) return content;
    return Scaffold(body: content);
  }
}

class _BookList extends StatelessWidget {
  final List<BibleBook> books;
  const _BookList({required this.books});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: books.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, i) {
        final book = books[i];
        final completed = app.completedChaptersForBook(book.id);
        final percent = book.chapterCount == 0 ? 0.0 : completed / book.chapterCount;
        final isDone = completed == book.chapterCount;

        return Card(
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => BookDetailScreen(bookId: book.id))),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(book.arabicName,
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
                            ),
                            if (isDone) const Icon(Icons.check_circle, color: AppColors.accent, size: 20),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text('$completed / ${book.chapterCount} إصحاح', style: Theme.of(context).textTheme.bodySmall),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: LinearProgressIndicator(
                            value: percent,
                            minHeight: 6,
                            backgroundColor: AppColors.primary.withOpacity(0.08),
                            valueColor: const AlwaysStoppedAnimation(AppColors.primary),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text('${(percent * 100).toStringAsFixed(0)}%',
                      style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.primary)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
