import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../models/bible_models.dart';
import '../../services/notification_service.dart';
import '../../theme/app_theme.dart';
import '../home/home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _page = 0;
  int? _selectedDays;
  int _preferredHour = 20;
  int _preferredMinute = 0;

  static const int totalPages = 6;

  void _next() {
    if (_page < totalPages - 1) {
      _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    } else {
      _finish();
    }
  }

  Future<void> _finish() async {
    final app = context.read<AppState>();
    if (_selectedDays != null) {
      await app.createPlan(_selectedDays!);
    }
    final settings = app.settings;
    settings.preferredHour = _preferredHour;
    settings.preferredMinute = _preferredMinute;
    settings.onboardingComplete = true;
    await app.saveSettings(settings);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView(
                controller: _controller,
                onPageChanged: (i) => setState(() => _page = i),
                children: [
                  _WelcomePage(onNext: _next),
                  _IntroStatsPage(onNext: _next),
                  _MotivationPage(onNext: _next),
                  _WhereAreYouPage(onNext: _next),
                  _GoalPage(
                    selectedDays: _selectedDays,
                    onSelect: (d) => setState(() => _selectedDays = d),
                    onNext: _next,
                  ),
                  _ReadingTimePage(
                    onHourMinute: (h, m) => setState(() {
                      _preferredHour = h;
                      _preferredMinute = m;
                    }),
                    onFinish: _finish,
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(totalPages, (i) {
                  final active = i == _page;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: active ? 22 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: active ? AppColors.primary : AppColors.primary.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PageScaffold extends StatelessWidget {
  final Widget child;
  final String? buttonLabel;
  final VoidCallback? onNext;

  const _PageScaffold({required this.child, this.buttonLabel, this.onNext});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        children: [
          Expanded(child: Center(child: child)),
          if (onNext != null)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: onNext,
                child: Text(buttonLabel ?? 'التالي'),
              ),
            ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

class _WelcomePage extends StatelessWidget {
  final VoidCallback onNext;
  const _WelcomePage({required this.onNext});

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: onNext,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.menu_book_rounded, size: 96, color: AppColors.primary),
          const SizedBox(height: 24),
          Text('فتشوا الكتب',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Text(
            '"لأنكم تظنون أن لكم فيها حياة أبدية، وهي التي تشهد لي."',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontStyle: FontStyle.italic),
          ),
          const SizedBox(height: 8),
          Text('يوحنا 5:39', style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _IntroStatsPage extends StatelessWidget {
  final VoidCallback onNext;
  const _IntroStatsPage({required this.onNext});

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: onNext,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'فتشوا الكتب هو رفيقك لمتابعة قراءتك في الكتاب المقدس، خطوة بخطوة، إصحاحًا بعد إصحاح.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 28),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            alignment: WrapAlignment.center,
            children: const [
              _StatChip(number: '73', label: 'سفرًا'),
              _StatChip(number: '1335', label: 'إصحاحًا فعليًا'),
              _StatChip(number: '46', label: 'سفرًا في العهد القديم'),
              _StatChip(number: '27', label: 'سفرًا في العهد الجديد'),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            'يتبع التطبيق ترتيب الكتاب المقدس كما تسلّمته الكنيسة القبطية الأرثوذكسية، ويشمل الأسفار القانونية الثانية في مواضعها التقليدية.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String number;
  final String label;
  const _StatChip({required this.number, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 130,
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: BoxDecoration(
        color: AppColors.primary.withOpacity(0.06),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Text(number, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.primary)),
          const SizedBox(height: 4),
          Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13)),
        ],
      ),
    );
  }
}

class _MotivationPage extends StatelessWidget {
  final VoidCallback onNext;
  const _MotivationPage({required this.onNext});

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: onNext,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _VerseCard(text: 'فتشوا الكتب، لأنكم تظنون أن لكم فيها حياة أبدية.', ref: 'يوحنا 5:39'),
          const SizedBox(height: 16),
          _VerseCard(text: 'سراج لرجلي كلامك ونور لسبيلي.', ref: 'مزمور 119:105'),
          const SizedBox(height: 16),
          _VerseCard(text: 'أما أنت فاثبت على ما تعلمت.', ref: '2 تيموثاوس 3:14'),
        ],
      ),
    );
  }
}

class _VerseCard extends StatelessWidget {
  final String text;
  final String ref;
  const _VerseCard({required this.text, required this.ref});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.accent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border(right: BorderSide(color: AppColors.accent, width: 3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(text, textAlign: TextAlign.right, style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 6),
          Text(ref, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.accent)),
        ],
      ),
    );
  }
}

class _WhereAreYouPage extends StatelessWidget {
  final VoidCallback onNext;
  const _WhereAreYouPage({required this.onNext});

  static const options = [
    'لم أبدأ بعد',
    'قرأت بعض الإصحاحات',
    'قرأت عدة أسفار',
    'أنا بالفعل أقرأ الكتاب بانتظام',
  ];

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('إنت وصلت لفين؟', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 24),
          ...options.map((o) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: onNext,
                    child: Text(o),
                  ),
                ),
              )),
          const SizedBox(height: 8),
          Text(
            'يمكنك لاحقًا تحديد الأسفار والإصحاحات التي قرأتها بالفعل من شاشة الأسفار.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

class _GoalPage extends StatelessWidget {
  final int? selectedDays;
  final ValueChanged<int> onSelect;
  final VoidCallback onNext;
  const _GoalPage({required this.selectedDays, required this.onSelect, required this.onNext});

  static const Map<String, int> options = {
    '30 يوم': 30,
    '60 يوم': 60,
    '90 يوم': 90,
    '6 شهور': 182,
    'سنة': 365,
  };

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: selectedDays != null ? onNext : null,
      buttonLabel: 'حساب خطتي',
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('عايز تخلص الكتاب المقدس في قد إيه؟', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 24),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: options.entries.map((e) {
              final selected = selectedDays == e.value;
              return ChoiceChip(
                label: Text(e.key),
                selected: selected,
                onSelected: (_) => onSelect(e.value),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => onSelect(90),
            child: const Text('اختيار مدة مخصصة (90 يوم افتراضيًا)'),
          ),
        ],
      ),
    );
  }
}

class _ReadingTimePage extends StatefulWidget {
  final void Function(int hour, int minute) onHourMinute;
  final VoidCallback onFinish;
  const _ReadingTimePage({required this.onHourMinute, required this.onFinish});

  @override
  State<_ReadingTimePage> createState() => _ReadingTimePageState();
}

class _ReadingTimePageState extends State<_ReadingTimePage> {
  String _choice = 'بالليل';
  static const Map<String, List<int>> times = {
    'الصبح': [7, 0],
    'الظهر': [13, 0],
    'العصر': [17, 0],
    'بالليل': [20, 0],
  };
  bool _askedPermission = false;

  Future<void> _handleFinish() async {
    final t = times[_choice] ?? [20, 0];
    widget.onHourMinute(t[0], t[1]);
    widget.onFinish();
  }

  Future<void> _allowNotifications() async {
    setState(() => _askedPermission = true);
    await NotificationService.instance.requestPermission();
  }

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: _handleFinish,
      buttonLabel: 'ابدأ الرحلة',
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('بتحب تقرأ الكتاب غالبًا إمتى؟', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 20),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: times.keys.map((k) {
              return ChoiceChip(
                label: Text(k),
                selected: _choice == k,
                onSelected: (_) => setState(() => _choice = k),
              );
            }).toList(),
          ),
          const SizedBox(height: 28),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.06),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              children: [
                const Icon(Icons.notifications_active_outlined, color: AppColors.primary, size: 32),
                const SizedBox(height: 8),
                Text(
                  'نقدر نفكّرك كل يوم بوقت قراءتك، ونبعتلك آية من الآيات اللي حفظتها.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ElevatedButton(
                      onPressed: _askedPermission ? null : _allowNotifications,
                      child: Text(_askedPermission ? 'تم ✓' : 'السماح بالإشعارات'),
                    ),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: () => setState(() => _askedPermission = true),
                      child: const Text('لاحقًا'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
