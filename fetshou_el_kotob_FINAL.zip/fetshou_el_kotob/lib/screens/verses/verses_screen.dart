import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/app_state.dart';
import '../../theme/app_theme.dart';
import 'add_verse_sheet.dart';

class VersesScreen extends StatelessWidget {
  final bool embedded;
  const VersesScreen({super.key, this.embedded = false});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final verses = app.savedVerses;

    final body = verses.isEmpty
        ? Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.bookmark_border, size: 56, color: AppColors.primary),
                  const SizedBox(height: 12),
                  Text('آياتي', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 8),
                  Text('احفظ الآيات التي لمستك أثناء القراءة وستظهر هنا.',
                      textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
          )
        : ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: verses.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final v = verses[i];
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(v.text, style: Theme.of(context).textTheme.titleSmall),
                          ),
                          IconButton(
                            icon: Icon(v.isFavorite ? Icons.favorite : Icons.favorite_border,
                                color: v.isFavorite ? Colors.redAccent : null),
                            onPressed: () => app.toggleFavoriteVerse(v),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => app.deleteVerse(v.id),
                          ),
                        ],
                      ),
                      Text(v.reference, style: const TextStyle(color: AppColors.accent, fontWeight: FontWeight.w600)),
                      if (v.note != null) ...[
                        const SizedBox(height: 6),
                        Text(v.note!, style: Theme.of(context).textTheme.bodySmall),
                      ],
                      const SizedBox(height: 6),
                      Text(DateFormat('yyyy/MM/dd').format(v.createdAt), style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
              );
            },
          );

    final fab = FloatingActionButton(
      onPressed: () => showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (_) => const AddVerseSheet(),
      ),
      child: const Icon(Icons.add),
    );

    if (embedded) {
      return Stack(
        children: [
          body,
          Positioned(bottom: 16, left: 16, child: fab),
        ],
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('آياتي')),
      body: body,
      floatingActionButton: fab,
    );
  }
}
