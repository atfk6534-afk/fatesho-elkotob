import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_state.dart';
import 'theme/app_theme.dart';
import 'screens/onboarding/onboarding_screen.dart';
import 'screens/home/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FetshouElKotobApp());
}

class FetshouElKotobApp extends StatelessWidget {
  const FetshouElKotobApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState()..init(),
      child: Consumer<AppState>(
        builder: (context, app, _) {
          final themeMode = app.isReady ? app.settings.themeMode : 'system';
          return MaterialApp(
            title: 'فتشوا الكتب',
            debugShowCheckedModeBanner: false,
            locale: const Locale('ar'),
            supportedLocales: const [Locale('ar')],
            theme: AppTheme.light(),
            darkTheme: AppTheme.dark(),
            themeMode: switch (themeMode) {
              'light' => ThemeMode.light,
              'dark' => ThemeMode.dark,
              _ => ThemeMode.system,
            },
            builder: (context, child) => Directionality(
              textDirection: TextDirection.rtl,
              child: child!,
            ),
            home: !app.isReady
                ? const _SplashScreen()
                : (app.settings.onboardingComplete ? const HomeScreen() : const OnboardingScreen()),
          );
        },
      ),
    );
  }
}

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Icon(Icons.menu_book_rounded, size: 72, color: AppColors.primary),
      ),
    );
  }
}
