import 'package:uuid/uuid.dart';
import '../models/bible_models.dart';
import '../data/bible_repository.dart';
import 'progress_repository.dart';

/// Builds and maintains a reading plan. Divides the actual *remaining
/// chapter count* (not book count) across the chosen number of days, so
/// the daily workload reflects real reading volume.
class ReadingPlanService {
  final BibleRepository bible;
  final ProgressRepository progress;
  final _uuid = const Uuid();

  ReadingPlanService(this.bible, this.progress);

  /// Creates a new plan for [days] days, accounting for chapters the user
  /// has already completed (subtracted from the workload).
  ReadingPlan createPlan({required int days}) {
    final remaining = bible.totalChapters - progress.completedCount;
    final safeDays = days < 1 ? 1 : days;
    final chaptersPerDay = (remaining / safeDays).ceil().clamp(1, bible.totalChapters);

    final start = DateTime.now();
    final target = start.add(Duration(days: safeDays));

    return ReadingPlan(
      id: _uuid.v4(),
      startDate: start,
      targetDate: target,
      totalChapters: remaining,
      chaptersPerDay: chaptersPerDay,
    );
  }

  /// Recalculates a plan's daily pace based on chapters actually remaining
  /// and days actually remaining until the target date — used after the
  /// user falls behind or catches up, and after "لا يهمك، نكمل من النهارده".
  ReadingPlan recalculate(ReadingPlan plan) {
    final remaining = bible.totalChapters - progress.completedCount;
    final today = DateTime.now();
    final daysLeft = plan.targetDate.difference(today).inDays;
    final safeDaysLeft = daysLeft < 1 ? 1 : daysLeft;
    final newPace = (remaining / safeDaysLeft).ceil().clamp(1, bible.totalChapters);

    return ReadingPlan(
      id: plan.id,
      startDate: plan.startDate,
      targetDate: plan.targetDate,
      totalChapters: remaining,
      chaptersPerDay: newPace,
      status: plan.status,
    );
  }

  /// Extends the target date to keep the original daily pace instead of
  /// changing the pace — an alternative recovery strategy.
  ReadingPlan pushTargetDate(ReadingPlan plan) {
    final remaining = bible.totalChapters - progress.completedCount;
    final extraDays = (remaining / plan.chaptersPerDay).ceil();
    final newTarget = DateTime.now().add(Duration(days: extraDays));
    return ReadingPlan(
      id: plan.id,
      startDate: plan.startDate,
      targetDate: newTarget,
      totalChapters: remaining,
      chaptersPerDay: plan.chaptersPerDay,
      status: plan.status,
    );
  }

  DateTime estimatedFinishDate({required int chaptersPerDay}) {
    final remaining = bible.totalChapters - progress.completedCount;
    if (chaptersPerDay <= 0) return DateTime.now();
    final days = (remaining / chaptersPerDay).ceil();
    return DateTime.now().add(Duration(days: days));
  }

  int get remainingChapters => bible.totalChapters - progress.completedCount;
}
